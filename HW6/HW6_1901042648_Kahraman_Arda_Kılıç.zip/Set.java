/** 
 * Set interface
 * 
 * @author ArdaKılıc 
 * 
 * */
public interface Set<E> extends Collection<E> 
{
    /**
     * 
     * No function declarations.
     *  
     * */
}

