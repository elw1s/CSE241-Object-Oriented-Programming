/** 
 * List interface
 * 
 * @author ArdaKılıc 
 * 
 * */
public interface List<E> extends Collection<E> 
{
    /**
     * 
     * No function declarations.
     *  
     * */ 
}