#include <iostream>
#include "hex_game.h"

/* Test program for hex_game library. */


using namespace std;

int main(){

	startGame();


	return 0;
}