#include <iostream>
#include "hex_game.h"

/* Test program for hex_game library. */

int main(){

	startGame();


	return 0;
}